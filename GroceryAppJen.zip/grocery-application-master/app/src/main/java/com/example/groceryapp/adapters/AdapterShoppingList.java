package com.example.groceryapp.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.groceryapp.R;
import com.example.groceryapp.activities.MainUserActivity;
import com.example.groceryapp.models.*;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AdapterShoppingList extends RecyclerView.Adapter<AdapterShoppingList.HolderCartProducts>{

    private Context context;
    public ArrayList<ModelProduct> cartProducttList;
    MainUserActivity mainuserobj;

    AdapterCallback listener;
    public AdapterShoppingList (Context context, ArrayList<ModelProduct> cartProducttList ) {
        this.context = context;
        this.cartProducttList = cartProducttList;
    }

    @NonNull
    @Override
    public HolderCartProducts onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate layout
        View view = LayoutInflater.from(context).inflate(R.layout.show_shoppinglist,parent,false);
        return new HolderCartProducts(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderCartProducts holder, int position) {

        //get data
        ModelProduct modelCartProduct = cartProducttList.get(position);
        String id = modelCartProduct.getProductId();
        String icon = modelCartProduct.getProductIcon();
        String name = modelCartProduct.getProductName();
        String quantity=modelCartProduct.getProductquant();
        double averageprice=modelCartProduct.getAveragePrice();

        ///set data
        holder.shLproductNameTv.setText(name);
        holder.shLproductQuantityTv.setText(quantity);
        holder.shLproductavgpriceTv.setText(String.valueOf(averageprice)+"$");

        try{
            Picasso.get().load(icon).placeholder(R.drawable.ic_store).into(holder.shLproductIconIv);
        }
        catch (Exception e){
            holder.shLproductIconIv.setImageResource(R.drawable.ic_store);
        }
        holder.removeIv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // RemoveProductFromCart(cartProducttList,position);
                listener.onProductRemoved(cartProducttList.get(position));
            }
        });

    }
public void setListener(AdapterCallback listener){
        this.listener = listener;
}

    private void RemoveProductFromCart(ArrayList<ModelProduct> ListOfcartProduct, int pos)
    {
        ListOfcartProduct.remove(ListOfcartProduct.get(pos));
       // mainuserobj.showShoppingListUI();
        mainuserobj.LoadCartProducts();


    }

    @Override
    public int getItemCount() {
        return cartProducttList.size();
    }

    //view holder
    class HolderCartProducts extends RecyclerView.ViewHolder{

        private ImageView shLproductIconIv,removeIv;
        private TextView shLproductNameTv, shLproductQuantityTv,shLproductavgpriceTv;

        public HolderCartProducts(@NonNull View itemView) {
            super(itemView);

            shLproductIconIv = itemView.findViewById(R.id.shLproductIconIv);
            shLproductNameTv = itemView.findViewById(R.id.shLproductNameTv);
            shLproductQuantityTv = itemView.findViewById(R.id.shLproductquantityTv);
            shLproductavgpriceTv=itemView.findViewById(R.id.shLproductavgpriceTv);
            removeIv=itemView.findViewById(R.id.removeIv);
        }
    }

}
